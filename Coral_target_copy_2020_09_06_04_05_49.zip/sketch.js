var bananaImage,obstacleImage,obstaclegroup,background;
var score, bananagroup, createEdgeSprites,edges, ground;
var banana, obstacle;

function preload() {
backImage=loadImage("jungle.png");
player_running=
loadAnimation("Monkey_01.png","Monkey_02.png","Monkey_03.png","Monkey_04.png","Monkey_05.png","Monkey_06.png","Monkey_07.png","Monkey_08.png","Monkey_09.png","Monkey_10.png");
playerimg=loadImage("player.png");
bananaimg=loadImage("banana.png");
obstacleimg=loadImage("obstacle.png"); 
bananaImage = loadImage("Banana.png");
obstacle_img = loadImage("stone.png");
}

function setup() {
  createCanvas(400, 400);
  banana.addImage = (bananaimg);
  obstacle.addImage = (obstacleimg);
  background.addImage= (backgroundimg);
  
  player = createSprite(100,340,20,50);
  player.addImage(playerimg);
  
  ground = createSprite(400,350,800,10);
  ground.x=ground.width/2;
  


function draw() {
  background(220);
  
  switch(score){
    case 10: player.scale=0.12;
    break;
    case 20:player.scale=0.14;
      break;
    case 30: player.scale=0.16;
      break;
    case 40: player.scale=0.18;
      break;
    default: break;
  }

 
  if(obstaclesGroup.isTouching(player)){
    player.scale=0.2;
  }
  
  stroke("white");
  textSize(20);
  fill("white");
  text("Score: "+ score, 500,50);
}
  ground=createEdgeSprites();
  //Bounce Off the Left Edge only
  player.bounceOff(ground[0]); 
  player.bounceOff(ground,explosion);
  player.collide(ground);

  if (keyDown("space")) {
player.velocityY= -12;
}player.velocityY = player.velocityY + 0.8;

var survivalTime=0;
stroke("black");
textSize(20);
fill("black");
survivalTime=Math.ceil(frameCount/frameRate());
text("Survival Time:"+ survivalTime, 100,50);

drawSprites();
}

function explosion()
{
  player.velocityY=random(-8,8);
}

function banana (){
var banana = createSprite (600,200,40,10);
if (World.frameCount % 80 === 0) {
banana.scale=0.05
banana.y = randomNumber(120,200);
banana.velocityX=-5;
banana.lifetime = 150;
bananaGroup.add(banana);
}
}

function obstacle (){
var obstacle = createSprite (620,320,40,10)
if(World.frameCount % 300 === 0){
obstacle.scale=0.15;
obstacle.velocityX= -5;
obstacle.lifetime = 150;
ObstacleGroup.add(obstacle);
}
}



  
